package com.ssafy.compare;

public class Book implements Comparable<Book> {
	public String isbn;
	public String title;
	public int price;
	
	public Book(String isbn, String title, int price) {
		this.isbn = isbn;
		this.title = title;
		this.price = price;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(isbn);
		builder.append(" | ");
		builder.append(title);
		builder.append("\t| ");
		builder.append(price);
		return builder.toString();
	}

	@Override
	public int compareTo(Book o) {
		return this.isbn.compareTo(o.isbn);
	}
}

